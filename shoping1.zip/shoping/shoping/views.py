from django.shortcuts import render, HttpResponse
from contact.models import ContactMessage
from django.shortcuts import render, redirect
from myapp.models import UserData

def index(request):
    return render(request, 'index.html')

def about(request):
    return render(request, 'about.html')

def cart(request):
    return render(request, 'cart.html')

def elex(request):
    return render(request, 'elex.html')

def fashion(request):
    return render(request, 'fashion.html')

def grocery(request):
    return render(request, 'grocery.html')

def login(request):
    return render(request, 'login.html')

def contact(request):
    return render(request, 'contact.html')

def reg(request):
    return render(request, 'registration.html')

def contactcode(request):
    if request.method == 'POST':
        name = request.POST.get('name')
        email = request.POST.get('email')
        subject = request.POST.get('subject')
        message = request.POST.get('message')
        ContactMessage.objects.create(name=name,email=email,subject=subject,message=message)
        return HttpResponse("<script>alert('Data have been sent'); window.location.href='../contact'</script>")



def register_view(request):
    if request.method == 'POST':
        name = request.POST['name']
        email = request.POST['email']
        mobile = request.POST['mobile']
        password = request.POST['password']
        
        # Save to DB
        UserData.objects.create(
            name=name,
            email=email,
            mobile=mobile,
            password=password
        )
        return redirect('/login/')
    return render(request, 'register.html')

def login_view(request):
    msg = ''
    if request.method == 'POST':
        email = request.POST['email']
        password = request.POST['password']
        user = UserData.objects.filter(email=email, password=password).first()
        if user:
            return render(request, 'dashboard.html', {'user': user})
        else:
            msg = "Invalid credentials"
            return redirect('/index/')
    return render(request, 'login.html', {'msg': msg})

def dashboard_view(request):
    return render(request, 'dashboard.html')
