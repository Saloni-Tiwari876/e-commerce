from django.contrib import admin
from django.urls import path
from . import views
from .views import ContactMessage  # ✅ Import from project-level views
from . import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', views.index),
    path('cart/', views.cart),
    path('about/', views.about),
    path('elex/', views.elex),
    path('fashion/', views.fashion),
    path('grocery/', views.grocery),
    path('login/', views.login),
    path('reg/', views.reg),
    path('contact/', views.contact),
    path('contactcode/', views.contactcode),
    path('admin/', admin.site.urls),
    path('register/', views.register_view, name='register'),
    path('login/', views.login_view, name='login'),
    path('dashboard/', views.dashboard_view, name='dashboard'),
]


